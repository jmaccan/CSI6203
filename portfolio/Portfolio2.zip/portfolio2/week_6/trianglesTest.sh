#!/bin/bash

# Author: J Maccan
# Date: September 2019
# Version: NA

# Module 6 Task 3 - Guessing game



printError()
{
    echo -e "\033[31mERROR:\033[0m $1"
}

getNumber()
{
    read -p "$1: "
    while (( $REPLY <= 1 || $REPLY >= 100 )); do
        printError "Value must be between 1 and 100"
        read -p "Try again..."
    done
    echo $REPLY
}

echo "Welcome to the guessing game"

base=$(getNumber "Enter base value of triangle")
height=$(getNumber "Enter height of triangle")
triArea = (( (base*height)/2 ))
echo "Area of triangle is: $triArea"
echo "Goodbye"


