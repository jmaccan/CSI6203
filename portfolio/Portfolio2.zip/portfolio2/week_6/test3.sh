#!/bin/bash

# Author: J Maccan
# Date: September 2019
# Version: NA

# Module 6 Task 4 - Triangles



area = (( 5*5 / 2 ))
echo "The area for a triangle with a base: 5 and height: 5 is: $area"





