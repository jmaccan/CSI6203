#!/bin/bash

# Author: J Maccan
# Date: September 2019
# Version: NA

# Module 6 Task 4 - Triangles


# for loop for each base val
for((b=1; b<=10; b++))
do
    # for loop for each height val
    for((h=1; h<=10; h++))
    do
        # calc and echo area in decimal format using bc
        echo -n "The area for a triangle with a base: $b and height: $h is: "
        echo "scale=2; $b*$h/2" | bc -q
    done    
done

exit 0




