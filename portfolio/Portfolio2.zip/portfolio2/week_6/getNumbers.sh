#!/bin/bash

# Author: J Maccan
# Date: September 2019
# Version: NA

# Module 6 Task 2


# print error function
printError()
{
    echo -e "\033[31mERROR:\033[0m $1"
}

# get number function
getNumber()
{
    read -p "$1: "
    # repeat prompt uuntil number in range is entered
    while (($REPLY < $2 || $REPLY > $3)); do
        printError "input must be between $2 and $3"
        read -p "$1: "
    done
}


echo "start of script"
# call get num function
getNumber "Enter number between 1 and 10" 1 10
echo "Thank you"

# call get number function
getNumber "Enter number between 10 and 20" 10 20
echo "Thank you"