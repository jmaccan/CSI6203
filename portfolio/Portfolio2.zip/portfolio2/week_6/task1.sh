#!/bin/bash

# Author: J Maccan
# Date: September 2019
# Version: NA

# Module 6 Taskk 1

VAR1=$1

printError()
{
    echo -e "\033[31mERROR:\033[0m $VAR1"
}

printError
