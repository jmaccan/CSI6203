#!/bin/bash
name=lucy
echo '$name'