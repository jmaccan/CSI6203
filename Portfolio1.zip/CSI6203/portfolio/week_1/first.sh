#!/bin/bash
echo "Hi there!"
exit 22