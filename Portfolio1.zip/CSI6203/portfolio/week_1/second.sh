#! /bin/bash
echo "Hi there!"
echo "It's good to see you $1!"
echo "you too $2!"
exit 0